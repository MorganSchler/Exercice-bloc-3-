class ArticleService {
    // Création d'un article
    create(data) {
      const article = new Article(data);
      return article.save();
    }
  
    // Mise à jour d'un article
    update(id, data) {
      return Article.findByIdAndUpdate(id, data, { new: true });
    }
  
    // Suppression d'un article
    delete(id) {
      return Article.deleteOne({ _id: id });
    }
  }
  