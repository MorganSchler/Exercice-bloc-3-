class ArticlesController {
    // Création d'un article
    async create(req, res, next) {
      try {
        const article = await articlesService.create(req.body);
        res.json(article);
      } catch (err) {
        next(err);
      }
    }
  
    // Mise à jour d'un article
    async update(req, res, next) {
      try {
        const updatedArticle = await articlesService.update(req.params.id, req.body);
        res.json(updatedArticle);
      } catch (err) {
        next(err);
      }
    }
  
    // Suppression d'un article
    async delete(req, res, next) {
      try {
        await articlesService.delete(req.params.id);
        res.status(204).send();
      } catch (err) {
        next(err);
      }
    }
  }
  