const User = require("./users.model");
const bcrypt = require("bcrypt");

class UserService {
  getAll() {
    return User.find({}, "-password");
  }
  get(id) {
    return User.findById(id, "-password");
  }
  create(data) {
    const user = new User(data);
    return user.save();
  }
  update(id, data) {
    return User.findByIdAndUpdate(id, data, { new: true });
  }
  delete(id) {
    return User.deleteOne({ _id: id });
  }
  async checkPasswordUser(email, password) {
    const user = await User.findOne({ email });
    if (!user) {
      return false;
    }
    const bool = await bcrypt.compare(password, user.password);
    if (!bool) {
      return false;
    }
    return user._id;
  }
}
class ArticleService {
  // Création d'un article
  create(data) {
    const article = new Article(data);
    return article.save();
  }

  // Mise à jour d'un article
  update(id, data) {
    return Article.findByIdAndUpdate(id, data, { new: true });
  }

  // Suppression d'un article
  delete(id) {
    return Article.deleteOne({ _id: id });
  }
}

module.exports = new UserService();
