module.exports = {
  apps: [
    {
      script: 'server.js',
      instances: 3,
      autorestart: true,
      watch: false,
      max_memory_restart: '200M',
      log_file: '/logs/err.log',
      name: "app",
      script: "./www/app.js",
      env_production: {
        NODE_ENV: "production",
      },
    },
  ],
};
